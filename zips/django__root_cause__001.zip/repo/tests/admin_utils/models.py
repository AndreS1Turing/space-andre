from django.contrib import admin
from django.db import models
from django.utils.translation import gettext_lazy as _


class Site(models.Model):
    domain = models.CharField(max_length=100)

    def __str__(self):
        return self.domain


class Article(models.Model):
    """
    A simple Article model for testing
    """

    site = models.ForeignKey(Site, models.CASCADE, related_name="admin_articles")
    title = models.CharField(max_length=100)
    hist = models.CharField(
        max_length=100,
        verbose_name=_("History"),
        help_text=_("History help text"),
    )
    created = models.DateTimeField(null=True)

    def __str__(self):
        return self.title

    def test_from_model(self):
        return "nothing"

    @admin.display(description="not What you Expect")
    def test_from_model_with_override(self):
        return "nothing"


class ArticleProxy(Article):
    class Meta:
        proxy = True


class Cascade(models.Model):
    num = models.PositiveSmallIntegerField()
    parent = models.ForeignKey("self", models.CASCADE, null=True)

    def __str__(self):
        return str(self.num)


class DBCascade(models.Model):
    num = models.PositiveSmallIntegerField()
    parent = models.ForeignKey("self", models.DB_CASCADE, null=True)

    def __str__(self):
        return str(self.num)

    class Meta:
        required_db_features = {"supports_on_delete_db_cascade"}


class Event(models.Model):
    date = models.DateTimeField(auto_now_add=True)


class Location(models.Model):
    event = models.OneToOneField(Event, models.CASCADE, verbose_name="awesome event")


class Guest(models.Model):
    event = models.OneToOneField(Event, models.CASCADE)
    name = models.CharField(max_length=255)

    class Meta:
        verbose_name = "awesome guest"


class EventGuide(models.Model):
    event = models.ForeignKey(Event, models.DO_NOTHING)


class Vehicle(models.Model):
    pass


class VehicleMixin(Vehicle):
    vehicle = models.OneToOneField(
        Vehicle,
        models.CASCADE,
        parent_link=True,
        related_name="vehicle_%(app_label)s_%(class)s",
    )

    class Meta:
        abstract = True


class Car(VehicleMixin):
    pass
