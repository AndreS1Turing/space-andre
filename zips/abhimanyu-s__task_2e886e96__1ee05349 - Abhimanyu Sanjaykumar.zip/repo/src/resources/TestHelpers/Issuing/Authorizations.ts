// File generated from our OpenAPI spec

import {StripeResource} from '../../../StripeResource.js';
const stripeMethod = StripeResource.method;
export const Authorizations = StripeResource.extend({
  create: stripeMethod({
    method: 'POST',
    fullPath: '/v1/test_helpers/issuing/authorizations',
  }),
  capture: stripeMethod({
    method: 'POST',
    fullPath: '/v1/test_helpers/issuing/authorizations/{authorization}/capture',
  }),
  expire: stripeMethod({
    method: 'POST',
    fullPath: '/v1/test_helpers/issuing/authorizations/{authorization}/expire',
  }),
  finalizeAmount: stripeMethod({
    method: 'POST',
    fullPath:
      '/v1/test_helpers/issuing/authorizations/{authorization}/finalize_amount',
  }),
  increment: stripeMethod({
    method: 'POST',
    fullPath:
      '/v1/test_helpers/issuing/authorizations/{authorization}/increment',
  }),
  respond: stripeMethod({
    method: 'POST',
    fullPath:
      '/v1/test_helpers/issuing/authorizations/{authorization}/fraud_challenges/respond',
  }),
  reverse: stripeMethod({
    method: 'POST',
    fullPath: '/v1/test_helpers/issuing/authorizations/{authorization}/reverse',
  }),
});
