rich
====

.. automodule:: rich
    :members:
    

