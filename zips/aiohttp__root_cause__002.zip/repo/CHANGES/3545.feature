Drop custom router support
